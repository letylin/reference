# -*- coding: utf-8 -*-
"""
Created on Thu Nov 15 13:33:29 2018

@author: Ping-Chen Lin
"""
import numpy as np
import pandas as pd
roidata = []
with open('weeklyROI_new.txt', 'r') as fin: 
    for line in fin.readlines():
        roidata.append(line.split())
    print('檔案內資料量總數 = %d' %(len(roidata)))
    #將股票代號與股票名稱合併到temp串列
    aryi = np.asarray(roidata)
    stocknobylist = np.unique(aryi[:,0]) 
    print('使用numpy的unique方法去除重覆值')
    print(stocknobylist)
    print('使用pandas的drop_duplicates方法去除重覆值')
    dfi = pd.DataFrame(aryi[:,0:2])
    stocknobydataframe = dfi.drop_duplicates()
    print(stocknobydataframe) 