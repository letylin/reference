# -*- coding: utf-8 -*-
"""
Created on Mon Nov 12 15:39:46 2018

@author: Ping-Chen Lin
"""
import pandas as pd
import plotly.offline as pyo
from plotly.graph_objs import Figure, Data
import time

pyo.offline.init_notebook_mode()
#讀取xls檔案 96年左營站_20080801
area = '高屏' 
city = '左營'
year = '106'
fn = './' + year +'年 ' + area +'空品區/' + year +'年' + city + '站_20180309.xls'
df1=pd.read_excel(fn)
#過濾指定測項的資料
df2 = df1[df1['測項'] == 'PM2.5']
#將非數字用成nan
#將改第三欄以後的非數字格式改成空值
df2.iloc[:,3:] = df2.iloc[:,3:].apply(pd.to_numeric, errors='coerce')
df3 = df2
#計算1年之中00-23小時平均值
df4 = df3.iloc[:,3:27].mean()
#計算每天24時一個平均值(每列的第3欄到27欄的平均)
df3['avgrow'] = df3.iloc[:, 3:27].mean(axis = 1)
x_date = df3.iloc[:, 0]
y_avgrow = df3.iloc[:, 27]
#畫統計圖計算1年之中00-23小時平均值
trace1 = {'type':'scatter',
        'x' : list(range(0, 24)), #設定x軸為24小時
        'y' : list(df4), #設定df4, 00-23小時年平均值
        'name':'scatter plot',
        'mode':'lines+markers', 
        'marker' : {
                'size' : 14, 
                'color' : 'rgba(152, 0, 0, .8)',
                'line' : {
                        'width' : 1,
                        }
                }
        }
title1 = year + area + city + 'PM2.5 每小時年平均值'
layout1 = {'title': title1,
         'xaxis':{'title':'24小時'},
         'yaxis':{'title':'PM2.5'}}
data = Data([trace1])
fig = Figure(data=data, layout=layout1)
pyo.plot(fig,filename='temp-plot1.html')
time.sleep(0.1) #暫停執行給定1秒數，等待圖1顯示完再顯示圖2
#畫統計圖每天24時一個平均值(每列的第3欄到27欄的平均)

trace2 = {'type':'scatter',
        'x' : df3.iloc[:, 0], #設定df3日期為x軸
        'y' : df3.iloc[:, 27], #設定df3之27欄日平均為y軸
        'name':'scatter plot',
        'mode':'markers', 
        'marker' : {
                'size' : 14, 
                'color' : 'rgba(100, 182, 193, .9)',
                'line' : {
                        'width' : 1,
                        }
                }
        }
title2 = year + area + city + 'PM2.5 日平均值'               
layout2 = {'title':title2,
         'xaxis':{'title':'日期'},
         'yaxis':{'title':'PM2.5'}}
data = Data([trace2])
fig['layout'].update(layout2)
fig = Figure(data=data, layout=layout2)
pyo.plot(fig,filename='temp-plot2.html')
